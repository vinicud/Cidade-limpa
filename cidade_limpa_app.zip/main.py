
import streamlit as st
import pandas as pd
import folium
from streamlit_folium import st_folium

st.set_page_config(page_title="Cidade Limpa", layout="wide")

st.title("🌱 Cidade Limpa - Reporte de Lixo nas Ruas")

data = pd.DataFrame({
    "Latitude": [-23.5505, -23.5510],
    "Longitude": [-46.6333, -46.6340],
    "Local": ["Rua A", "Rua B"],
    "Tipo de Lixo": ["Plástico", "Orgânico"]
})

m = folium.Map(location=[-23.5505, -46.6333], zoom_start=14)

for _, row in data.iterrows():
    folium.Marker(
        location=[row["Latitude"], row["Longitude"]],
        popup=f"{row['Local']} - {row['Tipo de Lixo']}"
    ).add_to(m)

st.subheader("🗺️ Mapa de Lixo Reportado")
st_folium(m, width=700, height=500)
